GATO GARCIA RENDERS - SAMPLE PACKAGE (web size)
https://gregoriomorales4176-rgb.github.io/gatogarciaart-renders/

This is what you get for every model, shown smaller so it downloads fast.
Real deliveries are full size: 2048 x 2048 PNG.

  barbarian_000 / 045 / 090 / 180 / 270   Five angles
  barbarian_sheet                         Contact sheet, all angles in one image
  barbarian_turntable.mp4 / .gif          360 degree turntable, 4 seconds
  barbarian_hero_shot                     Hero shot on the tabletop scene (+$5)
  transparent/                            Transparent versions for banners and ads
                                          (full deliveries include every angle)

Normal shot: $10 per model. Normal + hero shot: $15. Your first render is free.
Delivered within 24 hours, usually the same day.

Contact: gatogarciaart@gmail.com  |  instagram.com/gatogarciaart

CREDIT
The model is "Sons of the Mountain - Barbarians: the Invasion" by Fed Tabula Games,
licensed under CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/).
Source: https://sketchfab.com/3d-models/none-8637ae16b7384a3f9e72f0ebaa01fc65
Rendered by Gato Garcia.
